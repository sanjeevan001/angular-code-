import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PostService } from '../post.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-post-detail',
  templateUrl: './post-detail.component.html',
  styleUrls: ['./post-detail.component.css'],
  providers: [MessageService],
})
export class PostDetailComponent implements OnInit {
  postForm: FormGroup;
  id: number = 0;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private postService: PostService,
    private fb: FormBuilder,
    private messageService: MessageService
  ) {
    this.postForm = this.fb.group({
      id: [{ value: '', disabled: true }],
      title: ['', Validators.required],
      body: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.id = +id;
      this.postService.getPost(this.id).subscribe(
        (data) => {
          this.postForm.patchValue(data);
        },
        (error) => {
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: 'Failed to load post details',
          });
        }
      );
    }
  }

  onSubmit(): void {
    if (this.postForm.valid) {
      this.postService
        .updatePost({ ...this.postForm.value, id: this.id })
        .subscribe(
          (data) => {
            this.messageService.add({
              severity: 'success',
              summary: 'Success',
              detail: 'Post updated successfully',
            });
            this.router.navigate(['/']);
          },
          (error) => {
            this.messageService.add({
              severity: 'error',
              summary: 'Error',
              detail: 'Failed to update post',
            });
          }
        );
    }
  }
}
