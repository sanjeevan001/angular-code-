import { Component, OnInit } from '@angular/core';
import { PostService } from '../post.service';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css'],
})
export class PostsComponent implements OnInit {
  posts: any[] = [];

  constructor(
    private postService: PostService,
    private router: Router,
    private messageService: MessageService
  ) {}

  ngOnInit(): void {
    this.postService.getPosts().subscribe((data) => {
      this.posts = data;
    });
  }

  viewPost(id: number): void {
    this.router.navigate(['/posts', id]);
  }

  editPost(id: number): void {
    this.router.navigate(['/posts/edit', id]);
  }

  deletePost(id: number): void {
    if (confirm('Are you sure you want to delete this post?')) {
      this.postService.deletePost(id).subscribe(() => {
        this.posts = this.posts.filter((post) => post.id !== id);
        this.messageService.add({
          severity: 'success',
          summary: 'Success',
          detail: 'Post deleted successfully',
        });
      });
    }
  }
}
