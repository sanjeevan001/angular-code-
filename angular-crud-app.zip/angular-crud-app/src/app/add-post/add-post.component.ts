import { Component } from '@angular/core';
import { PostService } from '../post.service';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-add-post',
  templateUrl: './add-post.component.html',
  styleUrls: ['./add-post.component.css'],
})
export class AddPostComponent {
  postForm: FormGroup;

  constructor(private postService: PostService, private fb: FormBuilder) {
    this.postForm = this.fb.group({
      title: [''],
      body: [''],
    });
  }

  onSubmit(): void {
    this.postService.addPost(this.postForm.value).subscribe((data) => {
      alert('Post added successfully');
      this.postForm.reset();
    });
  }
}
